'use strict';
var AWS = require('aws-sdk');
var agg = require('aws-kinesis-agg');

exports.handler = (event, context, callback) => {
    var cloudwatch = new AWS.CloudWatch();
    console.log('Processing records: ', event.Records.length);
    console.log('Received event:', JSON.stringify(event, null, 2));

    event.Records.forEach((record) => {
        console.log('Processing records: ', record.kinesis.sequenceNumber);

        // Deaggregate KPL records
        agg.deaggregateSync(record.kinesis, true, (err, userRecords) => {
            console.log('Deaggregating records: ' + userRecords.length);
            if (err) {
                console.log(err);
                callback(err);
                return;
            }

            // Iterate over them
            userRecords.forEach((record) => {
                var tweetData = new Buffer(record.data, 'base64');
                var tweet = JSON.parse(tweetData.toString('ascii'));

                var params = {
                    MetricData: [
                        {
                            MetricName: 'tweets-count',
                            Timestamp: tweet.timestamp_ms / 1000,
                            Unit: "None",
                            Value: 1.0
                        }
                    ],
                    Namespace: 'pluralsight-kinesis'
                };             

                cloudwatch.putMetricData(params, function(err, data) {
                    if (err) {
                        console.log(err, err.stack);
                        callback(err);
                    }
                })
            });
        });

        // Parse a tweet 
        // Store value 1 for each tweet

    });
    callback(null, `Successfully processed ${event.Records.length} records.`);
};
